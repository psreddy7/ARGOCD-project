def call() {
  sh 'echo Hi From DevOps Team'
}
